<?php

include( 'header.php' );
$title = "Home";
$activeNav = 'Home'; 

?>


<section class="faq-bgg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="cover-text wow fadeInUp" data-wow-delay=".7s">FAQ</h2>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="accordion-container flex-column-center">
                    <h1>FREQUENTLY ASKED QUESTIONS</h1>
                    <ul class="accordion-list">
                        <li>
                            <div class="accordion-title">
                                <figure>
                                    <i class="fas fa-caret-right"></i>
                                    <!-- <svg width="10" height="7" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 .799l4 4 4-4" stroke="#F47B56" stroke-width="2" fill="none"
                                            fill-rule="evenodd" />
                                    </svg> -->
                                </figure>
                                <h2>Typically, how much does it cost to install lights?</h2>
                            </div>
                            <p>Installation prices can vary a lot from home to home, which is why we offer free quotes.
                                A simple single story home will probably start around $1000. As you add bushes, trees
                                and sides of the home, the price will go up. A two story home will typically start at
                                around $1300.</p>
                        </li>
                        <li>
                            <div class="accordion-title">
                                <figure>
                                    <i class="fas fa-caret-right"></i>
                                    <!-- <svg width="10" height="7" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 .799l4 4 4-4" stroke="#F47B56" stroke-width="2" fill="none"
                                            fill-rule="evenodd" />
                                    </svg> -->
                                </figure>
                                <h2>Can I use my own lights?</h2>
                            </div>
                            <p>Unfortunately, we cannot use your lights. Sorting out someone else’s lights can be
                                problematic and it doesn’t allow us to offer our 48 hour maintenance guarantee: if
                                anything goes wrong, we will be out within 48 hours to fix it. In most cases this is
                                included with your contract. <br><br>

                                Another benefit to our lights, beside them all being LED, is that each strand is
                                customized to your home. If you have a</p>
                        </li>
                        <li>
                            <div class="accordion-title">
                                <figure>
                                    <i class="fas fa-caret-right"></i>
                                    <!-- <svg width="10" height="7" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 .799l4 4 4-4" stroke="#F47B56" stroke-width="2" fill="none"
                                            fill-rule="evenodd" />
                                    </svg> -->
                                </figure>
                                <h2>Are you hiring?</h2>
                            </div>
                            <p>The Christmas season is our busiest time of the year. If you are interested in hanging
                                Christmas lights and a understand the importance of the customer and the need for
                                perfection, please call us at (702) 861-4672. We train all of our staff to ensure they
                                are not only safe, but do the right job.</p>
                        </li>
                        <li>
                            <div class="accordion-title">
                                <figure>
                                    <i class="fas fa-caret-right"></i>
                                    <!-- <svg width="10" height="7" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 .799l4 4 4-4" stroke="#F47B56" stroke-width="2" fill="none"
                                            fill-rule="evenodd" />
                                    </svg> -->
                                </figure>
                                <h2>Do I need to sign a multi-year contract?</h2>
                            </div>
                            <p>No. We want to earn your business, not lock you into it.</p>
                        </li>
                        <li>
                            <div class="accordion-title">
                                <figure>
                                    <i class="fas fa-caret-right"></i>
                                    <!-- <svg width="10" height="7" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M1 .799l4 4 4-4" stroke="#F47B56" stroke-width="2" fill="none"
                                            fill-rule="evenodd" />
                                    </svg> -->
                                </figure>
                                <h2>How much is my electric bill going to be?</h2>
                            </div>
                            <p>All of our lights are LED lights, which helps keep your electric bill low. It will vary
                                from house to house based on whether you want the Griswold lighting experience or just
                                lights on the eaves. <br><br>

                                A typical single story home may have 150 LED bulbs at 0.8 watts each. If you keep them
                                on for 5 hours a day for 50 days, that would be 30kWh.<br><br>

                                As of this writing, electricitylocal.com lists the rate for Las Vegas, NV at 12.15¢ per
                                kWh. That means the above lights would cost $3.65 in electricity over the
                                season.<br><br>

                                When you get your quote, ask how much your particular install will cost and we can
                                calculate it out for you.</p><br><br>
                        </li>
                    </ul>
                </div>
                <!-- <figure class="img-box">
      <svg width="191" height="184" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"><defs><filter x="-97.9%" y="-76.3%" width="295.8%" height="313.7%" filterUnits="objectBoundingBox" id="a"><feOffset dy="25" in="SourceAlpha" result="shadowOffsetOuter1"/><feGaussianBlur stdDeviation="25" in="shadowOffsetOuter1" result="shadowBlurOuter1"/><feColorMatrix values="0 0 0 0 0.209139076 0 0 0 0 0.0691446444 0 0 0 0 0.478091033 0 0 0 0.497159091 0" in="shadowBlurOuter1"/></filter><path id="b" d="M0 27.756v53.87l41.968 24.035 47.387-28.025v-53.87"/></defs><g fill="none" fill-rule="evenodd"><g transform="translate(50.93 2.125)"><use fill="#000" filter="url(#a)" xlink:href="#b"/><use fill="#FF9271" xlink:href="#b"/></g><path fill="#DF5C34" fill-rule="nonzero" d="M92.899 53.917v53.87l47.387-28.026v-53.87z"/><path fill="#F47B56" fill-rule="nonzero" d="M50.93 29.88L99.624 2.126l40.662 23.767-47.387 28.025z"/><path d="M94.013 14.49a25.942 25.942 0 0114.207 3.129c2.486 1.462 3.844 2.988 4.036 4.579.192 1.59-.628 2.975-2.562 4.143a9.115 9.115 0 01-2.985 1.18c-.869.205-1.76.295-2.652.269l-.974-.077c.091.217.151.446.18.68a3.132 3.132 0 01-.513 1.552 5.704 5.704 0 01-2.1 2.065 12.633 12.633 0 01-6.7 1.77 13.247 13.247 0 01-6.957-1.757c-1.999-1.18-3.023-2.566-3.1-4.156a4.49 4.49 0 012.562-4.015 8.488 8.488 0 012.357-1.013 9.175 9.175 0 012.037-.346h.705l-1.282-.77 3.6-2.244 8.34 4.912a4.377 4.377 0 004.15 0c1.769-1.103 1.137-2.552-1.895-4.348a19.261 19.261 0 00-10.556-2.347 21.67 21.67 0 00-11.018 3.168c-3.023 1.89-4.522 4.143-4.496 6.76 0 2.564 1.601 4.848 4.714 6.682a21.015 21.015 0 0011.146 2.655 20.926 20.926 0 0011.017-2.925 12.353 12.353 0 003.062-2.565 5.683 5.683 0 001.28-2.18l.18-.808 4.753.269c.008.145.008.29 0 .436a8.216 8.216 0 01-.346 1.154 8.303 8.303 0 01-.82 1.72 11.912 11.912 0 01-1.69 2 15.952 15.952 0 01-2.755 2.13 25.602 25.602 0 01-9.326 3.36 35.176 35.176 0 01-10.877.192 24.896 24.896 0 01-9.339-3.053 12.127 12.127 0 01-5.304-5.566 8.192 8.192 0 010-6.593 12.692 12.692 0 015.266-5.759 28.966 28.966 0 0114.655-4.284zm4.663 13.262c-.17-.891-.77-1.64-1.601-2.001a6.579 6.579 0 00-3.33-.911 5.619 5.619 0 00-3.101.795 2.283 2.283 0 00-1.281 2.001c.117.89.69 1.654 1.512 2.014a6.54 6.54 0 003.394.86 6.092 6.092 0 003.254-.847 2.065 2.065 0 001.205-1.911" fill="#3E2928" fill-rule="nonzero"/></g></svg>
    </figure> -->
                <img class="img-box" src="./images/illustration-box-desktop.svg" alt="">
            </div>
            <script src="./main.js"></script>
            </body>
        </div>
    </div>
    </div>
</section>

<section class="info">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h4>If you have more questions, please call or text us at (702) 861-4672 or email us at
                   <a href="#_"> info@holidaysperfected.com</a></h4>
            </div>
        </div>
    </div>
</section>

<script>
    let accordion = document.querySelector('.accordion-list');
let items = accordion.querySelectorAll('li');
let questions = accordion.querySelectorAll('.accordion-title');

questions.forEach(question => question.addEventListener('click', toggleAccordion));

function toggleAccordion() {
    thisItem = this.parentNode;
    items.forEach(item => {
        if (thisItem == item) {
            thisItem.classList.toggle('open');
            return;
        }
        item.classList.remove('open');
    })
}
</script>


<?php include('footer.php')?>