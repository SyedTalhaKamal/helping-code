<?php

include( 'header.php' );
$title = "services";
$activeNav = 'services'; 

?>


<section class="services-bgg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="cover-text wow fadeInUp" data-wow-delay=".7s">Services</h2>
            </div>
        </div>
    </div>
</section>
<section class="chrs-ligh">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <hr>
                <h1>Christmas Lights</h1>
                <h4>Residential - Take a Closer Look</h4>
            </div>
        </div>
    </div>
</section>

<section class="gallary">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <main class="main">
                    <div class="container">
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-1.jpg" data-fancybox="gallery" data-caption="IMG_34221_1">
                                    <img src="images/img-1.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-2.jpg" data-fancybox="gallery" data-caption="IMG_20200101_064728_3">
                                    <img src="images/img-2.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-3.jpg" data-fancybox="gallery"
                                    data-caption="MVIMG_20200101_191953_2">
                                    <img src="images/img-3.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-4.jpg" data-fancybox="gallery"
                                    data-caption="MVIMG_20191215_174119_2">
                                    <img src="images/img-4.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-5.jpg" data-fancybox="gallery"
                                    data-caption="MVIMG_20191207_212223_2">
                                    <img src="images/img-5.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-6.jpg" data-fancybox="gallery"
                                    data-caption="MVIMG_20191207_212056_2">
                                    <img src="images/img-6.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-7.jpg" data-fancybox="gallery" data-caption="IMG_20191224_164607_2">
                                    <img src="images/img-7.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-8.jpg" data-fancybox="gallery" data-caption="IMG_20191130_193638_2">
                                    <img src="images/img-8.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-9.jpg" data-fancybox="gallery" data-caption="IMG_20191215_164621_2">
                                    <img src="images/img-9.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-10.jpg" data-fancybox="gallery"
                                    data-caption="IMG_20191215_172355_2">
                                    <img src="images/img-10.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-11.jpg" data-fancybox="gallery"
                                    data-caption="IMG_20191223_180156_2">
                                    <img src="images/img-11.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-12.jpg" data-fancybox="gallery" data-caption="IMG_20191214_192757">
                                    <img src="images/img-12.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                        <div class="card">
                            <div class="card-image">
                                <a href="images/img-13.jpg" data-fancybox="gallery"
                                    data-caption="IMG_20191214_183955_1">
                                    <img src="images/img-13.jpg" alt="Image Gallery">
                                </a>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    </div>
</section>

<section class="light-led">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h4>LED Lights</h4>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <ul>
                    <li>
                        <i class="fas fa-tree"></i>
                        <span>Polycarbonate lenses are up to 200 times stronger than glass</span>
                    </li>
                    <li>
                        <i class="fas fa-tree"></i>
                        <span>Surface Mounted Device LED technology for brilliant light</span>
                    </li>
                    <li>
                        <i class="fas fa-tree"></i>
                        <span>
                            LED bulbs always remain cool to the touch</span>
                    </li>
                    <li>
                        <i class="fas fa-tree"></i>
                        <span>
                            0.8 Watts per bulb means a better electricity bill</span>
                    </li>
                    <li>
                        <i class="fas fa-tree"></i>
                        <span>Choose from smooth or faceted</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>

<section class="for-slider-ser">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="carousel-wrap">
                    <div class="owl-carousel">
                        <div class="item"><img src="images/slider-pic1.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic2.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic3.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic4.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic5.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic6.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic7.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic1.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic2.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic3.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic4.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic5.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic6.png" class="img-fluid"></div>
                        <div class="item"><img src="images/slider-pic7.png" class="img-fluid"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="qu-btn">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p>If you are interested in professionally installed lights, please call us at (702) 861-4672 or request
                    a quote online. </p>
            </div>
            <div class="col-lg-12 text-center mb-4">
                <a href="quote.php" class="for-green-btn">Request a Quote</a>
            </div>
        </div>
        <hr>
    </div>
</section>

<section class="helown">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1>Halloween</h1>
                <img src="images/helowin-pic.jpg" class="img-fluid helo-pic" alt="">
            </div>
        </div>
        <hr>
    </div>
</section>




<?php include('footer.php')?>