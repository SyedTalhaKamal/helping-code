<?php

include( 'header.php' );
$title = "Home";
$activeNav = 'Home'; 

?>


<section class="quote-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="cover-text wow fadeInUp" data-wow-delay=".7s">Request a Quote</h2>
            </div>
        </div>
    </div>
</section>

<section class="web-frm py-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <form action="mail.php" method="post">
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Name*</label>
                        <input type="text" name="name" class="form-control" id="first" >
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Email</label>
                        <input type="email" name="emailaddress" class="form-control" id="email" >
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Phone Number</label>
                        <input type="text" name="mobile" class="form-control" id="last" >
                    </div>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Address for decorations</label>
                        <input type="text" name="message" class="form-control" id="last" >
                        <small>Your address will allow us to look up your property before we call or email you.</small>
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Comment or Message</label>
                        <textarea class="form-control" id="msg" rows="6"></textarea>
                        <small>What services are you looking for? When is the best time to call you?</small>
                    </div>
                    <button type="submit" class="btn send-btn">submit</button>
                </form>
            </div>
        </div>
    </div>
</section>

<?php include('footer.php')?>