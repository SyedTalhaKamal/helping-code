<?php

include( 'header.php' );
$title = "Home";
$activeNav = 'Home'; 

?>


<section class="christmas-light">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="cover-text wow fadeInUp" data-wow-delay=".7s" >Christmas Light Installation</h2>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="for-h1">Holidays Perfected, LLC is offering professional lighting design and installation to
                    the Las Vegas valley.</h1>
                <p>Why choose Holidays Perfected</p>
                <ul class="for-ul">
                    <li>Licensed and Insured</li>
                    <li>Professionally trained</li>
                    <li>No multi-year contracts required</li>
                    <li>Locally owned company</li>
                    <li>Family operated</li>
                    <li>Free designs and estimates</li>
                    <li>48 hour maintenance included with our service. Under most circumstances, it is free (acts of God
                        and vandalism are not covered)</li>
                    <li>Removal of the lights is included</li>
                    <li>You don’t need to worry about storing any lights </li>
                    <li>You can pick new bulb colors or patterns from year to year</li>
                    <li>We handle residential, commercial and HOA properties </li>
                </ul>
            </div>
            <div class="col-lg-12 text-center">
                <h2 class="for-li8-need">Enjoy your holiday and let us simplify your lighting needs!</h2>
            </div>
            <div class="col-lg-12 text-center">
                <h2 class="for-li8-call">Call us at (702) 861-4672</h2>
                <h2 class="for-or">OR</h2>
            </div>
            <div class="col-lg-12 text-center">
                <a href="quote.php" class="for-green-btn">Request a Quote</a>
            </div>
        </div>
    </div>
</section>

<section class="web-counters">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="txt-red">Countdown to Christmas</h1>
                <div id="countdown">
                    <ul>
                        <li><span id="days"></span>Days</li>
                        <li><span id="hours"></span>Hours</li>
                        <li><span id="minutes"></span>Minutes</li>
                    </ul>
                    <script src="js/script.js"></script>
                </div>
            </div>
        </div>
    </div>
</section>


<?php include('footer.php')?>