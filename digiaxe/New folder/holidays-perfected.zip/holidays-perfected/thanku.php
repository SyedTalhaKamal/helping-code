<section class="quote-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="cover-text">Thankyou</h2>
            </div>
        </div>
    </div>
</section>