<!--footer start here-->

<footer>
    <div class="footer-top pb-2">
        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6 col-12">
                    <p>© 2021 Holidays Perfected, LLC info@holidaysperfected.com <br>
                        (702) 861-4672</p>
                    
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <h3><a href="services.php"> SERVICES</a></h3>
                    <ul class="for-list-non">
                        <li>Christmas Light Installation
                        </li>
                        <li>Halloween Lighting
                        </li>
                        <li>Coming Soon: Private Events
                        </li>

                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <h3><a href="about-us.php"> ABOUT US</a></h3>
                    <ul class="for-list-non">
                        <li><a href="about-us.php">About Us</a>
                        </li>
                        <li><a href="https://www.facebook.com/Holidays-Perfected-112061746837662">Join us on Facebook</a>
                        </li>

                    </ul>
                </div>
                <div class="col-lg-3 col-sm-6 col-12 ">
                    <h3><a href="faq.php"> FAQ</a></h3>
                </div>

            </div>
            
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container">
            <div class="row">
                
            </div>
        </div>
    </div>
</footer>

<!--footer end here-->

<script src="js/jquery.min.js"></script>
<script src="js/jquery.exzoom.js"></script>
<script src="js/jquery.fancybox.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/function.js"></script>
<script src="js/wow.min.js"></script>
<script>
new WOW().init();
</script>
</body>

</html>