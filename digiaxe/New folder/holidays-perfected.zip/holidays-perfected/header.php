<!doctype html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>  Holidays Perfected, LLC - Simplifying your holidays<?php echo ((isset($title))?$title:''); ?></title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link
        href="https://fonts.googleapis.com/css2?family=Jost:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/jquery.fancybox.css">
    <link rel="stylesheet" href="css/hover-min.css" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="icon" type="image/gif" sizes="32x32" href="images/fav.ico">
    <link rel="stylesheet" href="css/animate.css">
    <link href="fonts/fontawesome/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css" type="text/css" />
</head>

<!-- Back to top button -->
<a id="button"><i class="fas fa-angle-up"></i></a>

<body>
    <!--header start here-->

    <!-- <div class='preloader'>
        <div class="preloader-circle"></div>
    </div> -->
    <div class="h-main">
        <nav class="navbar navbar-expand-lg navbar-light p-0">
            <a class="navbar-brand" href="index.php"><img src="images/logo.png" class="logo-main" alt=""></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse " id="navbarNavAltMarkup">
                <div class="navbar-nav ml-auto">
                    <a class="nav-link " href="index.php">HOME</a>
                    <a class="nav-link" href="services.php">Services</a>
                    <a class="nav-link" href="about-us.php">About Us</a>
                    <a class="nav-link" href="faq.php">FAQ</a>
                </div>
            </div>
        </nav>
    </div>


    <!--header end here-->