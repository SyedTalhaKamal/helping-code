<?php

include( 'header.php' );
$title = "Home";
$activeNav = 'Home'; 

?>


<section class="about-us-page">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="cover-text wow fadeInUp" data-wow-delay=".7s">About Us</h2>
            </div>
        </div>
    </div>
</section>

<section class="about-txt py-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <p>Holidays Perfected, LLC was started based on the passion for perfection and the love for the
                    holidays. Every year we would enjoy holiday lights around the city but we were always taken away
                    from the beauty when we saw flaws in the displays; lights wouldn’t be straight or bulbs were burnt
                    out</p>
                <p>We are a family owned, licensed and insured company based in Henderson, Nevada. We are here to serve
                    the Las Vegas valley with professional lighting. </p>
                <p>If you would like to find out more about us, please email us at info@holidaysperfected.com or call us
                    at (702) 861-4672.</p>
                <p>You can also check out our Facebook page <a
                        href="https://www.facebook.com/Holidays-Perfected-112061746837662">here.</a></p>
            </div>
        </div>
    </div>
</section>

<?php include('footer.php')?>