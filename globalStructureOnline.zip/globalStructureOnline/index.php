<?php
$title = "Home";
$pg = 'Home';
include('header.php');
include('nav.php');
?>

<?php include('footer.php') ?>